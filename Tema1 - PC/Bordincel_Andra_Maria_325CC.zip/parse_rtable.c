#include "parse_rtable.h"

void read_rtable(char *tableName, int *tableDim, struct route_table_entry *rtable)
{
    FILE *fd;
    char prefix[15];
    char next_hop[15];
    char mask[15];
    int interface, i = 0;

    fd = fopen(tableName, "r");

    if(fd == NULL) {
        display_Errors("Nu s-a putut deschide tabela de rutare!");
    }

  // citesc continutul tabelei de rutare:
    while(fscanf(fd, "%s %s %s %d\n", prefix, next_hop, mask, &interface) != EOF) {
        rtable[i].prefix = inet_addr(prefix);
        rtable[i].next_hop = inet_addr(next_hop);
        rtable[i].mask = inet_addr(mask);
        rtable[i].interface = interface;
        i++;     
    }
    *tableDim = i;
}

void display_Errors(char *error)
{
	write(2, error, sizeof(char*));
	write(2, "\n", sizeof(char));
	exit(0);
}

int binary_search (struct route_table_entry *rtable, int left, int right,
					uint32_t destination_ip)
{
    // daca indexul stang este <= decat cel drept, incep cautarea
    if (left <= right) {
        // setez mijlocul
        int mid = left + (right - left) / 2;

        // daca ip-ul destinatie pe care aplic masca de retea de pe
        // indexul mid este egal cu ip-ul setat in prefixul de la
        // acest index returnez indexul mid.
        if ((destination_ip & rtable[mid].mask) == rtable[mid].prefix)
            return mid;

        // similar, daca este < decat  prefixul de la
        // acest index continui cautarea pe partea stanga a vectorului:
        if ((destination_ip & rtable[mid].mask) < rtable[mid].prefix)
            return binary_search(rtable, left, mid - 1, destination_ip);

        // daca nu se intra pe ramura anterioara, caut in jumatatea
        // dreapta a vectorului:
        return binary_search(rtable, mid + 1, right, destination_ip);
    }

    // daca nu am gasit pozitia cautata, intorc -1:
    return -1;
}