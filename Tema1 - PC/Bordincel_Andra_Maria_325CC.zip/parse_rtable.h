#ifndef __PARSE_RTABLE_H__
#define __PARSE_RTABLE_H__

#pragma once
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <arpa/inet.h>


struct route_table_entry {
	uint32_t prefix;
	uint32_t next_hop;
	uint32_t mask;
	int interface;
}__attribute__((packed));

struct route_table_entry* rtable;


void read_rtable(char *tableName, int *tableDim, struct route_table_entry* rtable);
void display_Errors(char *errorMsg);
int binary_search (struct route_table_entry *rtable, int l, int r,
					uint32_t destination_ip);

#endif