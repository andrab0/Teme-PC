#ifndef __ARP_H__
#define __ARP_H__

#include "parse_rtable.h"


struct arp_entry {
	uint32_t ip;
	uint8_t mac[6];
};

void parse_arp_table();
struct arp_entry *get_arp_entry(uint32_t ip);
struct route_table_entry *get_best_route(uint32_t dest_ip, int rtable_size);

int comparator(const void *addr1, const void *addr2);



#endif