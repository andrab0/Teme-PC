#include "arp.h"
#include "skel.h"

struct arp_entry *arp_table;
int arp_table_len;

struct arp_entry *get_arp_entry(uint32_t ip) {
    int i;
	for(i = 0; i < arp_table_len; i++) {
		if (arp_table[i].ip == ip)
			return &arp_table[i];
	}
    return NULL;
}

// functie de comparatie folosita in cautarea binara:
int comparator(const void *addr1, const void *addr2) 
{
    struct route_table_entry *a = (struct route_table_entry *)addr1; 
    struct route_table_entry *b = (struct route_table_entry *)addr2; 

    //in caz de egalitate dupa prefix sortez dupa masca:
    if(a->prefix == b->prefix)
    {
        if(a->mask < b->mask)
            return 1;
        else 
            return -1;
 
    }
    else{
        if(a->prefix > b->prefix)
            return 1;
        else
            return -1;
    }

    return 0;   
}


struct route_table_entry *get_best_route(uint32_t dest_ip, int rtable_size)
{
    int best_route_index = -1;

    qsort(rtable, rtable_size, sizeof(struct route_table_entry), comparator);
    best_route_index = binary_search (rtable, 0, rtable_size-1, dest_ip);

    if (best_route_index != -1)
        return &rtable[best_route_index];
    
    return NULL;
}

void parse_arp_table() 
{
	FILE *f;
	fprintf(stderr, "Parsing ARP table\n");
	f = fopen("arp_table.txt", "r");
	DIE(f == NULL, "Failed to open arp_table.txt");
	char line[100];
	arp_table = malloc(sizeof(struct  arp_entry) * 100);

	int i = 0;
	for(i = 0; fgets(line, sizeof(line), f); i++) {
		char ip_str[70], mac_str[70];
		sscanf(line, "%s %s", ip_str, mac_str);
		fprintf(stderr, "IP: %s MAC: %s\n", ip_str, mac_str);

		arp_table[i].ip = inet_addr(ip_str);

		int rc = hwaddr_aton(mac_str, arp_table[i].mac);
		DIE(rc < 0, "invalid MAC");
	}
	arp_table_len = i;
	fclose(f);
	fprintf(stderr, "Done parsing ARP table.\n");
}


/// FUNCTIE DIN LABORATOR:
// struct route_table_entry *get_best_route(uint32_t dest_ip, int rtable_size)
// {
// 	int i, best_index = -1;
// 	for (i = 0; i < rtable_size - 1; i++) {

// 		if((dest_ip & rtable[i].mask) == rtable[i].prefix ) {
// 			if(best_index == -1 || rtable[i].mask > rtable[best_index].mask)
// 				best_index = i;
// 		}
// 	}

// 	if (best_index == -1)
// 		return NULL;
	
// 	return &rtable[best_index];
// }


/// INCERCARE CU BSEARCH - nu prea mi-a iesit
// struct route_table_entry *get_best_route(uint32_t dest_ip, int *tableDim)
// {
//     int best_route_index = -1;

//     qsort(rtable, *tableDim, sizeof(struct route_table_entry), comparator);
//     best_route_index = (int) bsearch(&dest_ip, rtable, *tableDim, sizeof(struct route_table_entry), comparator);

//     if (best_route_index != -1)
//         return &rtable[best_route_index];
    
//     return NULL;
// }
