#include <queue.h>
#include "skel.h"
#include "parse_rtable.h"
#include "arp.h"

int main(int argc, char *argv[])
{
	packet m;
	int rc;

	init(argc - 2, argv + 2);

	int *rtableDim = malloc(sizeof(int));
	rtable = (struct route_table_entry*)malloc(999999*sizeof(struct route_table_entry));
	*rtableDim = 1;
	DIE((rtable == NULL), "Nu a putut fi alocata!");

	read_rtable(argv[1], rtableDim, rtable);

	parse_arp_table();

	while (1) {
		rc = get_packet(&m);
		DIE(rc < 0, "get_message");

		struct ether_header *eth_hdr = (struct ether_header *)m.payload;
		struct iphdr *ip_hdr = (struct iphdr *)(m.payload + sizeof(struct ether_header));
		struct icmphdr *icmp_hdr = parse_icmp(m.payload);

		if (icmp_hdr != NULL) {
			uint32_t myIP = inet_addr(get_interface_ip(m.interface));
			
			if (myIP == ip_hdr->daddr) {
				if(icmp_hdr->type == ICMP_ECHO) {
					send_icmp(ip_hdr->saddr, ip_hdr->daddr, eth_hdr->ether_dhost, eth_hdr->ether_shost,
								ICMP_ECHOREPLY, 0, m.interface, icmp_hdr->un.echo.id, icmp_hdr->un.echo.sequence);
					continue;
				}
			}
		}


		if(ip_checksum(ip_hdr, sizeof(struct iphdr)) != 0) {
			continue;
		}

		if (ip_hdr->ttl <= 1) {
				send_icmp_error(ip_hdr->saddr, ip_hdr->daddr,  eth_hdr->ether_dhost, eth_hdr->ether_shost, 11, 0, m.interface);
			continue;
		}

		struct route_table_entry *best_route = get_best_route(ip_hdr->daddr, *rtableDim);

		if(best_route == NULL){
			send_icmp_error(ip_hdr->saddr, ip_hdr->daddr,  eth_hdr->ether_dhost, eth_hdr->ether_shost, 3, 0, m.interface);
			continue;
		}

		ip_hdr->ttl--;
		ip_hdr->check = 0;
		ip_hdr->check = ip_checksum(ip_hdr, sizeof(struct iphdr));

		struct arp_entry *best_arp = get_arp_entry(best_route->next_hop);

		memcpy(eth_hdr->ether_dhost, best_arp->mac, sizeof(best_arp->mac));
		get_interface_mac(best_route->interface, eth_hdr->ether_shost);
		send_packet(best_route->interface, &m);
	}

	free(rtable);
	free(rtableDim);
	return 0;
}
