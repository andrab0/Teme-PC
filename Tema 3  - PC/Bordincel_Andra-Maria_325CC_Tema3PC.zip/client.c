#include <stdio.h>      /* printf, sprintf */
#include <stdlib.h>     /* exit, atoi, malloc, free */
#include <unistd.h>     /* read, write, close */
#include <string.h>     /* memcpy, memset */
#include <sys/socket.h> /* socket, connect */
#include <netinet/in.h> /* struct sockaddr_in, struct sockaddr */
#include <netdb.h>      /* struct hostent, gethostbyname */
#include <arpa/inet.h>
#include "helpers.h"
#include "requests.h"

#define HOST "34.118.48.238"
#define PORT 8080

//  functie pentru construirea payload-ului transmis catre
//  server:
char *crearePayload(char username[256], char password[256]);
//  functie pentru extragerea mesajului de eroare primit
//  de la server:
void mesajEroare(char *mesaj);

int main(int argc, char *argv[])
{
    int sockfd;
    char *message;
    char *response;
    char *request;

    while(1) {
        char comandaTastatura[30];
        memset(comandaTastatura, 0, 30);
        //  citesc comanda primita ca input:
        fgets(comandaTastatura, 29, stdin);
        char *command = strtok(comandaTastatura, " \n");

        //  deschid conexiunea cu serverul:
        sockfd = open_connection(HOST, PORT, AF_INET, SOCK_STREAM, 0);

        //  verific daca primesc comanda "register":
        if(!strcmp(command, "register")) {
            char username[256];
            char password[256];
            char **payload = (char **)malloc(1 * sizeof(char*));

            memset(username, 0, 256);
            memset(password, 0, 256);

            //  citesc username-ul si parola acestuia de la tastatura:
            printf("username=");
            fgets(username, 255, stdin);
            username[strlen(username) - 1] = '\0';
            printf("password=");
            fgets(password, 255, stdin);
            password[strlen(password) - 1] = '\0';

            //  creez payload-ul:
            payload[0] = crearePayload(username, password);

            //  trimit o cerere catre server:
            request = compute_post_request((char*) HOST, (char*) "/api/v1/tema/auth/register",
                                           (char*)"application/json", payload, 1, NULL, 0 );
            send_to_server(sockfd, request);

            //  primesc raspuns de la server:
            response = receive_from_server(sockfd);
            char *aux = strdup(response);

            //  verific daca s-a putut crea noul utilizator:
            if(strstr(aux, "HTTP/1.1 201") != NULL) {
                puts("Userul a fost creat!");
            } else {
                //  intorc mesajul de eroare primit de la server:
                if(basic_extract_json_response(response) != NULL) {
                    message = basic_extract_json_response(response);
                    mesajEroare(message);
                } else {
                    puts("Too many requests, please try again later.");
                }
            }

            //  eliberez memoria alocata:
            free(response);
            free(aux);
            free(request);
            free(payload[0]);
            free(payload);
        }

        //  verific daca s-a primit comanda "login" de la tastatura:
        if(!strcmp(command, "login")) {
            char username[256];
            char password[256];
            char **payload = (char **)malloc(1 * sizeof(char*));

            memset(username, 0, 256);
            memset(password, 0, 256);

            //  citesc username-ul si parola acestuia de la tastatura:
            printf("username=");
            fgets(username, 255, stdin);
            username[strlen(username) - 1] = '\0';
            printf("password=");
            fgets(password, 255, stdin);
            password[strlen(password) - 1] = '\0';

            //  creez payload-ul:
            payload[0] = crearePayload(username, password);

            //  trimit o cerere catre server:
            request = compute_post_request((char*) HOST, (char*) "/api/v1/tema/auth/login",
                                           (char*)"application/json", payload, 1, NULL, 0 );
            send_to_server(sockfd, request);

            //  primesc raspuns de la server:
            response = receive_from_server(sockfd);
            char *aux = strdup(response);

            //  verific daca utilizatorul s-a putut conecta:
            if(strstr(aux, "HTTP/1.1 200") != NULL) {
                puts("Userul s-a logat cu succes!");
            } else {
                //  intorc mesajul de eroare primit de la server:
                if(basic_extract_json_response(response) != NULL) {
                    message = basic_extract_json_response(response);
                    mesajEroare(message);
                } else {
                    puts("Too many requests, please try again later.");
                }
            }

            //  eliberez memoria alocata:
            free(response);
            free(aux);
            free(request);
            free(payload[0]);
            free(payload);
        }

        //  verific daca primesc comanda "exit":
        if(!strcmp(command, "exit")) {
            //  inchid conexiunea cu serverul:
            close_connection(sockfd);
            //  inchid aplicatia:
            return 0;
        }
    }

    close_connection(sockfd);
    return 0;
}

char *crearePayload(char username[256], char password[256]) {
    char *payload = malloc(1000 * sizeof(char));
    memset(payload, 0, 1000);

    //  construiesc forma necesasra pentru payload:
    strcpy(payload, "{");
	strcat(payload, "\"username\":\"");

    //  elimin caracterul newline din numele utilizatorului:
	char *p = strtok(username, "\n");
	strcat(payload, p);
	strcat(payload, "\",");
	strcat(payload, "\"password\":\"");

    //  elimin caracterul newline din parola utilizatorului:
    char *q = strtok(password, "\n");
	strcat(payload, q);
	strcat(payload, "\"}");

    //  returnez forma finala a payload-ului:
	return payload;
}

void mesajEroare(char *mesaj) {
    char *aux;
    int i;

    //  preiau mesajul de eroare transmis de server cuprins
    //  intre ultimele ghilimele:
    aux = strtok(mesaj, "\"");
    for (i = 0; i < 3; i++) {
        aux = strtok(NULL, "\"");
    }

    //  adaug caracterul null la finalul sirului construit:
    aux[strlen(aux)] = '\0';

    //  afisez mesajul de eroare:
    puts(aux);
}